package com.trustguardian.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
