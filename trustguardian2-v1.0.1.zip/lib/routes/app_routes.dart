import 'package:flutter/material.dart';
import '../presentation/news_container_screen/news_container_screen.dart';
import '../presentation/report_scam_screen/report_scam_screen.dart';
import '../presentation/discussion_screen/discussion_screen.dart';
import '../presentation/typeofscams_screen/typeofscams_screen.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String newsContainerScreen = '/news_container_screen';

  static const String reportScamScreen = '/report_scam_screen';

  static const String discussionScreen = '/discussion_screen';

  static const String typeofscamsScreen = '/typeofscams_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    newsContainerScreen: (context) => NewsContainerScreen(),
    reportScamScreen: (context) => ReportScamScreen(),
    discussionScreen: (context) => DiscussionScreen(),
    typeofscamsScreen: (context) => TypeofscamsScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
