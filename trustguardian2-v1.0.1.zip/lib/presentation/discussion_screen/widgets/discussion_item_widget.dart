import 'package:flutter/material.dart';
import 'package:trustguardian2/core/app_export.dart';

// ignore: must_be_immutable
class DiscussionItemWidget extends StatelessWidget {
  const DiscussionItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(5.h),
      decoration: AppDecoration.fillPrimaryContainer.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder15,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 13.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 11.h),
              child: Text(
                "Today  15.34pm",
                style: CustomTextStyles.bodyMediumAldrichErrorContainer,
              ),
            ),
          ),
          SizedBox(height: 12.v),
          Text(
            "I received a call today from bank told me that my acc....",
            style: CustomTextStyles.bodyMediumBoogalooErrorContainer,
          ),
          SizedBox(height: 36.v),
          Container(
            margin: EdgeInsets.only(left: 5.h),
            padding: EdgeInsets.symmetric(horizontal: 17.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: 15.v),
                  child: Text(
                    "See full",
                    style: CustomTextStyles.bodyMediumAldrichBlue600,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    top: 10.v,
                    bottom: 4.v,
                  ),
                  child: Text(
                    "Comment",
                    style: CustomTextStyles.bodyMediumAldrichBlue600,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    top: 10.v,
                    right: 13.h,
                    bottom: 5.v,
                  ),
                  child: Text(
                    "Share",
                    style: CustomTextStyles.bodyMediumAldrichBlue600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
