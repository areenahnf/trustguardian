import 'package:trustguardian2/widgets/app_bar/custom_app_bar.dart';
import 'package:trustguardian2/widgets/app_bar/appbar_leading_image.dart';
import 'package:trustguardian2/widgets/app_bar/appbar_title.dart';
import 'package:trustguardian2/widgets/app_bar/appbar_trailing_image.dart';
import 'widgets/discussion_item_widget.dart';
import 'package:trustguardian2/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:trustguardian2/core/app_export.dart';

class DiscussionScreen extends StatelessWidget {
  DiscussionScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        appBar: _buildAppBar(context),
        body: Container(
          width: SizeUtils.width,
          height: SizeUtils.height,
          decoration: BoxDecoration(
            color: appTheme.whiteA700,
            gradient: LinearGradient(
              begin: Alignment(0, 0.02),
              end: Alignment(0.9, 1.04),
              colors: [
                appTheme.whiteA700.withOpacity(0.35),
                appTheme.blue600,
                appTheme.whiteA70001,
              ],
            ),
          ),
          child: SizedBox(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(height: 36.v),
                _buildDiscussion(context),
              ],
            ),
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 67.v,
      leadingWidth: 52.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgBack,
        margin: EdgeInsets.only(
          left: 28.h,
          top: 24.v,
          bottom: 19.v,
        ),
      ),
      title: AppbarTitle(
        text: "Discussion",
        margin: EdgeInsets.only(left: 21.h),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgForward,
          margin: EdgeInsets.fromLTRB(16.h, 20.v, 16.h, 26.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildDiscussion(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 11.h),
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (
          context,
          index,
        ) {
          return Padding(
            padding: EdgeInsets.symmetric(vertical: 13.0.v),
            child: SizedBox(
              width: 321.h,
              child: Divider(
                height: 1.v,
                thickness: 1.v,
                color: theme.colorScheme.errorContainer.withOpacity(0.16),
              ),
            ),
          );
        },
        itemCount: 4,
        itemBuilder: (context, index) {
          return DiscussionItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.News:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      default:
        return DefaultWidget();
    }
  }
}
