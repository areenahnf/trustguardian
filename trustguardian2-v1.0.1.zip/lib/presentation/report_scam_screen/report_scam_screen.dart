import 'package:trustguardian2/widgets/app_bar/custom_app_bar.dart';
import 'package:trustguardian2/widgets/app_bar/appbar_leading_image.dart';
import 'package:trustguardian2/widgets/app_bar/appbar_title.dart';
import 'package:trustguardian2/widgets/app_bar/appbar_trailing_image.dart';
import 'package:trustguardian2/widgets/custom_text_form_field.dart';
import 'widgets/reportscam_item_widget.dart';
import 'package:trustguardian2/widgets/custom_elevated_button.dart';
import 'package:trustguardian2/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:trustguardian2/core/app_export.dart';

class ReportScamScreen extends StatelessWidget {
  ReportScamScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController vectorController = TextEditingController();

  TextEditingController vectorController1 = TextEditingController();

  TextEditingController vectorController2 = TextEditingController();

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 6.h,
            vertical: 23.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 10.h),
                child: Text(
                  "Report Web Fraud",
                  style: theme.textTheme.headlineSmall,
                ),
              ),
              SizedBox(height: 22.v),
              Container(
                width: 342.h,
                margin: EdgeInsets.only(left: 4.h),
                child: Text(
                  "We are here to help if you have encountered any suspicious or fraudulent activity online. Please provide us with as much detail as possible about the incident you wish to report. The information details will be confidential. ",
                  maxLines: 5,
                  overflow: TextOverflow.ellipsis,
                  style:
                      CustomTextStyles.bodySmallAldrichErrorContainer.copyWith(
                    height: 1.55,
                  ),
                ),
              ),
              SizedBox(height: 27.v),
              Padding(
                padding: EdgeInsets.only(left: 34.h),
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "Website URL ",
                        style: CustomTextStyles.bodySmallAldrichff000000,
                      ),
                      TextSpan(
                        text: "*",
                        style: CustomTextStyles.bodySmallAldrichffe9121f,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              SizedBox(height: 8.v),
              _buildVector(context),
              SizedBox(height: 15.v),
              _buildReportScam(context),
              SizedBox(height: 13.v),
              Padding(
                padding: EdgeInsets.only(left: 36.h),
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "Description of the Scam  ",
                        style: CustomTextStyles.bodySmallAldrichff000000,
                      ),
                      TextSpan(
                        text: "*",
                        style: CustomTextStyles.bodySmallAldrichffe9121f,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              SizedBox(height: 4.v),
              _buildVector1(context),
              SizedBox(height: 12.v),
              Padding(
                padding: EdgeInsets.only(left: 36.h),
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "Scammer Information  ",
                        style: CustomTextStyles.bodySmallAldrichff000000,
                      ),
                      TextSpan(
                        text: "*",
                        style: CustomTextStyles.bodySmallAldrichffe9121f,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              SizedBox(height: 9.v),
              _buildVector2(context),
              SizedBox(height: 40.v),
              Align(
                alignment: Alignment.center,
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 79.h),
                  padding: EdgeInsets.symmetric(horizontal: 12.h),
                  decoration: AppDecoration.outlineErrorContainer,
                  child: _buildSubmit(context),
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 41.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgBack,
        margin: EdgeInsets.only(
          left: 17.h,
          top: 28.v,
          bottom: 19.v,
        ),
      ),
      title: AppbarTitle(
        text: "Report Fraud",
        margin: EdgeInsets.only(left: 17.h),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgForward,
          margin: EdgeInsets.fromLTRB(17.h, 28.v, 17.h, 22.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildVector(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 34.h,
        right: 31.h,
      ),
      child: CustomTextFormField(
        controller: vectorController,
        alignment: Alignment.center,
      ),
    );
  }

  /// Section Widget
  Widget _buildReportScam(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 34.h,
        right: 165.h,
      ),
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            height: 3.v,
          );
        },
        itemCount: 8,
        itemBuilder: (context, index) {
          return ReportscamItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildVector1(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 36.h,
        right: 31.h,
      ),
      child: CustomTextFormField(
        controller: vectorController1,
        alignment: Alignment.center,
      ),
    );
  }

  /// Section Widget
  Widget _buildVector2(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 36.h,
        right: 31.h,
      ),
      child: CustomTextFormField(
        controller: vectorController2,
        textInputAction: TextInputAction.done,
        alignment: Alignment.center,
      ),
    );
  }

  /// Section Widget
  Widget _buildSubmit(BuildContext context) {
    return CustomElevatedButton(
      text: "Submit",
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.News:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      default:
        return DefaultWidget();
    }
  }
}
