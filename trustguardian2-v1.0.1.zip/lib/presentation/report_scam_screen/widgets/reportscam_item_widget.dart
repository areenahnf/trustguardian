import 'package:flutter/material.dart';
import 'package:trustguardian2/core/app_export.dart';

// ignore: must_be_immutable
class ReportscamItemWidget extends StatelessWidget {
  const ReportscamItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: "Type of Scams  ",
            style: CustomTextStyles.bodySmallAldrichff000000,
          ),
          TextSpan(
            text: "*",
            style: CustomTextStyles.bodySmallAldrichffe9121f,
          ),
        ],
      ),
      textAlign: TextAlign.left,
    );
  }
}
