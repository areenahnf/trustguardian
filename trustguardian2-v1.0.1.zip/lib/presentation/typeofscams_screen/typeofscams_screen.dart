import 'package:trustguardian2/widgets/app_bar/custom_app_bar.dart';
import 'package:trustguardian2/widgets/app_bar/appbar_leading_image.dart';
import 'package:trustguardian2/widgets/app_bar/appbar_title.dart';
import 'package:trustguardian2/widgets/app_bar/appbar_trailing_image.dart';
import 'package:trustguardian2/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:trustguardian2/core/app_export.dart';

class TypeofscamsScreen extends StatelessWidget {
  TypeofscamsScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(height: 28.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 13.h),
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.symmetric(horizontal: 6.h),
                          decoration: AppDecoration.gradientWhiteAToWhiteA70001,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: 9.h),
                                child: Text(
                                  "TRADING",
                                  style: theme.textTheme.titleLarge,
                                ),
                              ),
                              SizedBox(height: 15.v),
                              CustomImageView(
                                imagePath: ImageConstant.imgRectangle107x322,
                                height: 107.v,
                                width: 322.h,
                                radius: BorderRadius.circular(
                                  15.h,
                                ),
                              ),
                              SizedBox(height: 39.v),
                              Padding(
                                padding: EdgeInsets.only(left: 6.h),
                                child: Text(
                                  "INVESTMENT",
                                  style: theme.textTheme.titleLarge,
                                ),
                              ),
                              SizedBox(height: 9.v),
                              CustomImageView(
                                imagePath: ImageConstant.imgRectangle1,
                                height: 107.v,
                                width: 322.h,
                                radius: BorderRadius.circular(
                                  15.h,
                                ),
                              ),
                              SizedBox(height: 36.v),
                              Padding(
                                padding: EdgeInsets.only(left: 9.h),
                                child: Text(
                                  "FINANCIAL",
                                  style: theme.textTheme.titleLarge,
                                ),
                              ),
                              SizedBox(height: 16.v),
                              CustomImageView(
                                imagePath: ImageConstant.imgRectangle106x322,
                                height: 106.v,
                                width: 322.h,
                                radius: BorderRadius.circular(
                                  15.h,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 237.v),
                        _buildSeventyEight(context),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 72.v,
      leadingWidth: 52.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgBack,
        margin: EdgeInsets.only(
          left: 28.h,
          top: 24.v,
          bottom: 24.v,
        ),
      ),
      title: AppbarTitle(
        text: "Type Of Scams",
        margin: EdgeInsets.only(left: 21.h),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgForward,
          margin: EdgeInsets.fromLTRB(16.h, 25.v, 16.h, 26.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildSeventyEight(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Padding(
        padding: EdgeInsets.only(left: 37.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 57.v,
              width: 41.h,
              margin: EdgeInsets.only(
                top: 4.v,
                bottom: 2.v,
              ),
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: SizedBox(
                      width: 41.h,
                      child: Text(
                        "News",
                        maxLines: null,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodyMedium!.copyWith(
                          height: 4.57,
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      height: 36.v,
                      width: 37.h,
                      child: Stack(
                        alignment: Alignment.topRight,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgThumbsUp,
                            height: 36.v,
                            width: 37.h,
                            alignment: Alignment.center,
                          ),
                          CustomImageView(
                            imagePath: ImageConstant.imgNavNews,
                            height: 26.v,
                            width: 21.h,
                            alignment: Alignment.topRight,
                            margin: EdgeInsets.only(
                              top: 2.v,
                              right: 7.h,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 63.v,
              width: 41.h,
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: SizedBox(
                      width: 41.h,
                      child: Text(
                        "Home",
                        maxLines: null,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodyMedium!.copyWith(
                          height: 4.57,
                        ),
                      ),
                    ),
                  ),
                  CustomImageView(
                    imagePath: ImageConstant.imgHome,
                    height: 42.v,
                    width: 41.h,
                    alignment: Alignment.topCenter,
                  ),
                ],
              ),
            ),
            Container(
              height: 37.v,
              width: 48.h,
              margin: EdgeInsets.only(
                top: 3.v,
                bottom: 23.v,
              ),
              child: Stack(
                alignment: Alignment.centerLeft,
                children: [
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: EdgeInsets.only(bottom: 12.v),
                      child: Text(
                        "Profile",
                        style: theme.textTheme.bodyMedium,
                      ),
                    ),
                  ),
                  CustomImageView(
                    imagePath: ImageConstant.imgLockWhiteA700,
                    height: 37.v,
                    width: 38.h,
                    alignment: Alignment.centerLeft,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.News:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      default:
        return DefaultWidget();
    }
  }
}
