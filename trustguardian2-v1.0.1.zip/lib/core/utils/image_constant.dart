class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // News - Container images
  static String imgFire = '$imagePath/img_fire.png';

  static String imgRectangle9 = '$imagePath/img_rectangle_9.png';

  static String imgRectangle10 = '$imagePath/img_rectangle_10.png';

  static String imgRectangle11 = '$imagePath/img_rectangle_11.png';

  static String imgRectangle12 = '$imagePath/img_rectangle_12.png';

  // Report Scam images
  static String imgVector = '$imagePath/img_vector.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgVectorErrorcontainer =
      '$imagePath/img_vector_errorcontainer.svg';

  static String imgContrast = '$imagePath/img_contrast.svg';

  // TypeOfScams images
  static String imgRectangle107x322 = '$imagePath/img_rectangle_107x322.png';

  static String imgRectangle1 = '$imagePath/img_rectangle_1.png';

  static String imgRectangle106x322 = '$imagePath/img_rectangle_106x322.png';

  // Common images
  static String imgThumbsUp = '$imagePath/img_thumbs_up.svg';

  static String imgNavNews = '$imagePath/img_nav_news.svg';

  static String imgHome = '$imagePath/img_home.svg';

  static String imgLockWhiteA700 = '$imagePath/img_lock_white_a700.svg';

  static String imgBack = '$imagePath/img_back.png';

  static String imgForward = '$imagePath/img_forward.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
