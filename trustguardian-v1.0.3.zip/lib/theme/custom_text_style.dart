import 'package:flutter/material.dart';
import 'package:trustguardian/core/utils/size_utils.dart';
import 'package:trustguardian/theme/theme_helper.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodyLargeAldrichWhiteA70001 =>
      theme.textTheme.bodyLarge!.aldrich.copyWith(
        color: appTheme.whiteA70001,
      );
  static get bodyMediumAldrichBlue600 =>
      theme.textTheme.bodyMedium!.aldrich.copyWith(
        color: appTheme.blue600,
        fontSize: 15.fSize,
      );
  static get bodyMediumAldrichErrorContainer =>
      theme.textTheme.bodyMedium!.aldrich.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
        fontSize: 15.fSize,
      );
  static get bodyMediumBoogalooErrorContainer =>
      theme.textTheme.bodyMedium!.boogaloo.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
        fontSize: 15.fSize,
      );
  static get bodyMediumWhiteA700 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.whiteA700,
      );
  static get bodySmallAldrichErrorContainer =>
      theme.textTheme.bodySmall!.aldrich.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
        fontSize: 11.fSize,
      );
  static get bodySmallAldrichErrorContainer10 =>
      theme.textTheme.bodySmall!.aldrich.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
        fontSize: 10.fSize,
      );
  static get bodySmallAldrichff000000 =>
      theme.textTheme.bodySmall!.aldrich.copyWith(
        color: Color(0XFF000000),
      );
  static get bodySmallAldrichffe9121f =>
      theme.textTheme.bodySmall!.aldrich.copyWith(
        color: Color(0XFFE9121F),
      );
  static get bodySmallCaladeaErrorContainer =>
      theme.textTheme.bodySmall!.caladea.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
      );
  static get bodySmallErrorContainer => theme.textTheme.bodySmall!.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
      );
  static get bodySmallff000000 => theme.textTheme.bodySmall!.copyWith(
        color: Color(0XFF000000),
      );
  static get bodySmallff3836c1 => theme.textTheme.bodySmall!.copyWith(
        color: Color(0XFF3836C1),
      );
  // Headline text style
  static get headlineSmallBrunoAceOnPrimary =>
      theme.textTheme.headlineSmall!.brunoAce.copyWith(
        color: theme.colorScheme.onPrimary,
      );
  static get headlineSmallCalistogaWhiteA700 =>
      theme.textTheme.headlineSmall!.calistoga.copyWith(
        color: appTheme.whiteA700,
      );
  static get headlineSmallCatamaran =>
      theme.textTheme.headlineSmall!.catamaran.copyWith(
        fontWeight: FontWeight.w700,
      );
  static get headlineSmallCatamaranErrorContainer =>
      theme.textTheme.headlineSmall!.catamaran.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(0.38),
        fontWeight: FontWeight.w500,
      );
  static get headlineSmallWhiteA700 => theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.whiteA700,
      );
  // Title text style
  static get titleLargeCatamaran =>
      theme.textTheme.titleLarge!.catamaran.copyWith(
        fontSize: 22.fSize,
        fontWeight: FontWeight.w500,
      );
  static get titleLargeChenla => theme.textTheme.titleLarge!.chenla;
  static get titleLargeOnPrimary => theme.textTheme.titleLarge!.copyWith(
        color: theme.colorScheme.onPrimary,
      );
  static get titleMediumCatamaranErrorContainer =>
      theme.textTheme.titleMedium!.catamaran.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
      );
  static get titleMediumErrorContainer => theme.textTheme.titleMedium!.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
      );
}

extension on TextStyle {
  TextStyle get aldrich {
    return copyWith(
      fontFamily: 'Aldrich',
    );
  }

  TextStyle get roboto {
    return copyWith(
      fontFamily: 'Roboto',
    );
  }

  TextStyle get chenla {
    return copyWith(
      fontFamily: 'Chenla',
    );
  }

  TextStyle get brunoAce {
    return copyWith(
      fontFamily: 'Bruno Ace',
    );
  }

  TextStyle get caladea {
    return copyWith(
      fontFamily: 'Caladea',
    );
  }

  TextStyle get calistoga {
    return copyWith(
      fontFamily: 'Calistoga',
    );
  }

  TextStyle get catamaran {
    return copyWith(
      fontFamily: 'Catamaran',
    );
  }

  TextStyle get boogaloo {
    return copyWith(
      fontFamily: 'Boogaloo',
    );
  }
}
