import 'package:trustguardian/widgets/app_bar/custom_app_bar.dart';
import 'package:trustguardian/widgets/app_bar/appbar_leading_image.dart';
import 'package:trustguardian/widgets/app_bar/appbar_title.dart';
import 'package:trustguardian/widgets/custom_text_form_field.dart';
import 'package:trustguardian/widgets/custom_elevated_button.dart';
import 'package:trustguardian/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:trustguardian/core/app_export.dart';

class ProfileScreen extends StatelessWidget {
  ProfileScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  children: [
                    SizedBox(height: 17.v),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 38.h),
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(
                            ImageConstant.imgGroup14,
                          ),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: SizedBox(
                              height: 159.v,
                              width: 143.h,
                              child: Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  CustomImageView(
                                    imagePath:
                                        ImageConstant.imgRectangle142x143,
                                    height: 142.v,
                                    width: 143.h,
                                    radius: BorderRadius.circular(
                                      30.h,
                                    ),
                                    alignment: Alignment.topCenter,
                                  ),
                                  Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Text(
                                      "Sofia",
                                      style: theme.textTheme.titleLarge,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 14.v),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Container(
                              width: 173.h,
                              margin: EdgeInsets.only(right: 41.h),
                              child: Text(
                                "birthday: 26.9.1996\nJob : Finance Manager",
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: CustomTextStyles
                                    .bodyMediumAldrichErrorContainer
                                    .copyWith(
                                  height: 1.33,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 29.v),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              "Email :",
                              style: CustomTextStyles
                                  .bodyMediumAldrichErrorContainer,
                            ),
                          ),
                          SizedBox(height: 22.v),
                          CustomTextFormField(
                            controller: emailController,
                            hintText: "Sofia@gmail.com",
                            textInputType: TextInputType.emailAddress,
                          ),
                          SizedBox(height: 21.v),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              "Password :",
                              style: CustomTextStyles
                                  .bodyMediumAldrichErrorContainer,
                            ),
                          ),
                          SizedBox(height: 26.v),
                          Padding(
                            padding: EdgeInsets.only(
                              left: 4.h,
                              right: 3.h,
                            ),
                            child: CustomTextFormField(
                              controller: passwordController,
                              hintText: "**********",
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.visiblePassword,
                              obscureText: true,
                              contentPadding: EdgeInsets.symmetric(
                                horizontal: 17.h,
                                vertical: 14.v,
                              ),
                            ),
                          ),
                          SizedBox(height: 80.v),
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                              margin: EdgeInsets.symmetric(horizontal: 47.h),
                              padding: EdgeInsets.symmetric(horizontal: 12.h),
                              decoration: AppDecoration.outlineErrorContainer,
                              child: CustomElevatedButton(
                                text: "Save",
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(right: 4.h),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 41.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgBack,
        margin: EdgeInsets.only(
          left: 17.h,
          top: 10.v,
          bottom: 21.v,
        ),
      ),
      centerTitle: true,
      title: AppbarTitle(
        text: "Hi, Sofia!",
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {},
    );
  }
}
