import 'package:trustguardian/widgets/custom_text_form_field.dart';
import 'package:trustguardian/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:trustguardian/core/app_export.dart';

class SignupPageScreen extends StatelessWidget {
  SignupPageScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController closeController = TextEditingController();

  TextEditingController lockController = TextEditingController();

  TextEditingController vectorController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.whiteA70001,
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(horizontal: 30.h),
          child: Column(
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgCashOnWallet,
                height: 267.v,
                width: 276.h,
              ),
              SizedBox(height: 1.v),
              _buildSignUp(context),
              SizedBox(height: 23.v),
              SizedBox(
                height: 34.v,
                width: 221.h,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Container(
                        width: 30.h,
                        margin: EdgeInsets.only(
                          left: 21.h,
                          bottom: 4.v,
                        ),
                        child: Text(
                          "Email",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodySmall!.copyWith(
                            height: 1.67,
                          ),
                        ),
                      ),
                    ),
                    _buildClose(context),
                  ],
                ),
              ),
              SizedBox(height: 14.v),
              SizedBox(
                height: 34.v,
                width: 221.h,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        width: 58.h,
                        margin: EdgeInsets.only(left: 21.h),
                        child: Text(
                          "Username",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodySmall!.copyWith(
                            height: 1.67,
                          ),
                        ),
                      ),
                    ),
                    _buildLock(context),
                  ],
                ),
              ),
              SizedBox(height: 16.v),
              SizedBox(
                height: 34.v,
                width: 221.h,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        width: 53.h,
                        margin: EdgeInsets.only(left: 23.h),
                        child: Text(
                          "Password",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodySmall!.copyWith(
                            height: 1.67,
                          ),
                        ),
                      ),
                    ),
                    _buildVector(context),
                  ],
                ),
              ),
              SizedBox(height: 49.v),
              _buildSignUp1(context),
              SizedBox(height: 5.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  width: 195.h,
                  margin: EdgeInsets.only(left: 46.h),
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "Already have an account? ",
                          style: CustomTextStyles.bodySmallff000000,
                        ),
                        TextSpan(
                          text: " ",
                        ),
                        TextSpan(
                          text: "Log In",
                          style: CustomTextStyles.bodySmallff3836c1.copyWith(
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildSignUp(BuildContext context) {
    return SizedBox(
      height: 138.v,
      width: 298.h,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: SizedBox(
              width: 129.h,
              child: Text(
                "Sign Up",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: theme.textTheme.displaySmall!.copyWith(
                  height: 1.83,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SizedBox(
              width: 298.h,
              child: Text(
                "Experience the convenience of our platform by signing up today.",
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: CustomTextStyles.titleLargeChenla,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildClose(BuildContext context) {
    return CustomTextFormField(
      width: 221.h,
      controller: closeController,
      alignment: Alignment.center,
      suffix: Container(
        margin: EdgeInsets.symmetric(
          horizontal: 10.h,
          vertical: 8.v,
        ),
        child: CustomImageView(
          imagePath: ImageConstant.imgClose,
          height: 17.adaptSize,
          width: 17.adaptSize,
        ),
      ),
      suffixConstraints: BoxConstraints(
        maxHeight: 34.v,
      ),
    );
  }

  /// Section Widget
  Widget _buildLock(BuildContext context) {
    return CustomTextFormField(
      width: 221.h,
      controller: lockController,
      alignment: Alignment.center,
      suffix: Container(
        margin: EdgeInsets.symmetric(
          horizontal: 10.h,
          vertical: 9.v,
        ),
        child: CustomImageView(
          imagePath: ImageConstant.imgLock,
          height: 15.adaptSize,
          width: 15.adaptSize,
        ),
      ),
      suffixConstraints: BoxConstraints(
        maxHeight: 34.v,
      ),
    );
  }

  /// Section Widget
  Widget _buildVector(BuildContext context) {
    return CustomTextFormField(
      width: 221.h,
      controller: vectorController,
      textInputAction: TextInputAction.done,
      alignment: Alignment.center,
      suffix: Container(
        margin: EdgeInsets.symmetric(
          horizontal: 8.h,
          vertical: 7.v,
        ),
        child: CustomImageView(
          imagePath: ImageConstant.imgVector,
          height: 14.adaptSize,
          width: 14.adaptSize,
        ),
      ),
      suffixConstraints: BoxConstraints(
        maxHeight: 34.v,
      ),
      obscureText: true,
    );
  }

  /// Section Widget
  Widget _buildSignUp1(BuildContext context) {
    return CustomElevatedButton(
      text: "Sign Up",
      margin: EdgeInsets.symmetric(horizontal: 39.h),
    );
  }
}
