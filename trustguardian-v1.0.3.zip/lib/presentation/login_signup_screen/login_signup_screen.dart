import 'package:trustguardian/widgets/custom_outlined_button.dart';
import 'package:trustguardian/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:trustguardian/core/app_export.dart';

class LoginSignupScreen extends StatelessWidget {
  const LoginSignupScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: 14.h,
                vertical: 77.v,
              ),
              decoration: AppDecoration.fillOnPrimary,
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: EdgeInsets.only(left: 7.h),
                      child: Text(
                        "TRUST",
                        style: theme.textTheme.displayMedium,
                      ),
                    ),
                  ),
                  SizedBox(height: 21.v),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      "GUARDIAN",
                      style: theme.textTheme.displayMedium,
                    ),
                  ),
                  SizedBox(height: 19.v),
                  _buildNinetyNine(context),
                  SizedBox(height: 2.v),
                  Text(
                    "Log in ",
                    style: CustomTextStyles.titleLargeOnPrimary,
                  ),
                  SizedBox(height: 21.v),
                  _buildSignup(context),
                  SizedBox(height: 54.v),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildNinetyNine(BuildContext context) {
    return SizedBox(
      height: 354.v,
      width: 320.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(bottom: 16.v),
              child: Text(
                " ‘ Your Shield Against Financial Fraud. ‘",
                style: CustomTextStyles.bodyLargeAldrichWhiteA70001,
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgCashOnWallet,
            height: 354.v,
            width: 320.h,
            alignment: Alignment.center,
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSignup(BuildContext context) {
    return SizedBox(
      height: 53.v,
      width: 316.h,
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: Text(
              "Sign Up",
              style: theme.textTheme.titleLarge,
            ),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: Padding(
              padding: EdgeInsets.only(bottom: 11.v),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: CustomOutlinedButton(
                      text: "Signup",
                      margin: EdgeInsets.only(right: 4.h),
                    ),
                  ),
                  Expanded(
                    child: CustomElevatedButton(
                      text: "Login",
                      margin: EdgeInsets.only(left: 4.h),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
