import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:flutter/material.dart';
import 'package:trustguardian/core/app_export.dart';

// ignore_for_file: must_be_immutable
class HomepagePage extends StatelessWidget {
  const HomepagePage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.fillWhiteA,
          child: SizedBox(
            height: 732.v,
            width: double.maxFinite,
            child: Stack(
              alignment: Alignment.topRight,
              children: [
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    height: 48.v,
                    width: 288.h,
                    margin: EdgeInsets.only(top: 109.v),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color:
                              theme.colorScheme.errorContainer.withOpacity(1),
                          width: 1.h,
                        ),
                      ),
                      gradient: LinearGradient(
                        begin: Alignment(0, 0.5),
                        end: Alignment(1, 0.5),
                        colors: [
                          appTheme.blueGray200,
                          appTheme.whiteA700,
                        ],
                      ),
                    ),
                  ),
                ),
                CustomImageView(
                  imagePath: ImageConstant.imgSearch,
                  height: 43.v,
                  width: 161.h,
                  alignment: Alignment.topRight,
                  margin: EdgeInsets.only(top: 114.v),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 6.h,
                      vertical: 17.v,
                    ),
                    decoration: AppDecoration.gradientWhiteAToWhiteA,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "TrustGuardian",
                          style:
                              CustomTextStyles.headlineSmallBrunoAceOnPrimary,
                        ),
                        Spacer(
                          flex: 49,
                        ),
                        _buildTwentySeven(context),
                        SizedBox(height: 32.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(left: 17.h),
                            child: Text(
                              "Features:",
                              style: theme.textTheme.headlineSmall,
                            ),
                          ),
                        ),
                        SizedBox(height: 18.v),
                        _buildSixtyFive(context),
                        Spacer(
                          flex: 50,
                        ),
                      ],
                    ),
                  ),
                ),
                CustomImageView(
                  imagePath: ImageConstant.imgMore,
                  height: 53.v,
                  width: 45.h,
                  alignment: Alignment.topLeft,
                  margin: EdgeInsets.only(
                    left: 10.h,
                    top: 2.v,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildTwentySeven(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 17.h,
        vertical: 12.v,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadiusStyle.roundedBorder10,
        image: DecorationImage(
          image: fs.Svg(
            ImageConstant.imgGroup27,
          ),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 9.h),
            child: Row(
              children: [
                Padding(
                  padding: EdgeInsets.only(
                    top: 12.v,
                    bottom: 1.v,
                  ),
                  child: Text(
                    "Top News ",
                    style: theme.textTheme.headlineSmall,
                  ),
                ),
                CustomImageView(
                  imagePath: ImageConstant.imgFire,
                  height: 38.v,
                  width: 47.h,
                  margin: EdgeInsets.only(left: 8.h),
                ),
              ],
            ),
          ),
          SizedBox(height: 14.v),
          Container(
            width: 307.h,
            margin: EdgeInsets.only(left: 6.h),
            child: Text(
              "Malaysia recorded a significant rise....... \nBursa Malaysia joins Global WIW Champaign  to.....\nWho is to blame for Online Fraud?",
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodyLarge!.copyWith(
                decoration: TextDecoration.underline,
                height: 4.00,
              ),
            ),
          ),
          SizedBox(height: 9.v),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSixtyFive(BuildContext context) {
    return SizedBox(
      height: 116.v,
      width: 327.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(right: 239.h),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: 88.adaptSize,
                    width: 88.adaptSize,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            height: 88.adaptSize,
                            width: 88.adaptSize,
                            decoration: BoxDecoration(
                              color: appTheme.whiteA700,
                              borderRadius: BorderRadius.circular(
                                20.h,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: theme.colorScheme.errorContainer,
                                  spreadRadius: 2.h,
                                  blurRadius: 2.h,
                                  offset: Offset(
                                    0,
                                    4,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        CustomImageView(
                          imagePath: ImageConstant.imgPhishingStealData,
                          height: 64.v,
                          width: 52.h,
                          alignment: Alignment.center,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 8.v),
                  Text(
                    "Type of Scams",
                    style: theme.textTheme.bodyLarge,
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Padding(
              padding: EdgeInsets.only(
                left: 121.h,
                right: 118.h,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    height: 88.adaptSize,
                    width: 88.adaptSize,
                    decoration: BoxDecoration(
                      color: appTheme.whiteA70001,
                      borderRadius: BorderRadius.circular(
                        20.h,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: theme.colorScheme.errorContainer,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(
                            0,
                            4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 6.v),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: EdgeInsets.only(right: 11.h),
                      child: Text(
                        "Discussion",
                        style: theme.textTheme.bodyLarge,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: Padding(
              padding: EdgeInsets.only(left: 239.h),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: 88.adaptSize,
                    width: 88.adaptSize,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            height: 88.adaptSize,
                            width: 88.adaptSize,
                            decoration: BoxDecoration(
                              color: appTheme.whiteA700,
                              borderRadius: BorderRadius.circular(
                                20.h,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: theme.colorScheme.errorContainer,
                                  spreadRadius: 2.h,
                                  blurRadius: 2.h,
                                  offset: Offset(
                                    0,
                                    4,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        CustomImageView(
                          imagePath: ImageConstant.imgReport,
                          height: 44.v,
                          width: 82.h,
                          alignment: Alignment.center,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 8.v),
                  Text(
                    "Report Scams",
                    style: theme.textTheme.bodyLarge,
                  ),
                ],
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgDiscussion,
            height: 60.v,
            width: 201.h,
            alignment: Alignment.topCenter,
            margin: EdgeInsets.only(top: 12.v),
          ),
        ],
      ),
    );
  }
}
