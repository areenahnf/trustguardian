import 'package:trustguardian/widgets/custom_text_form_field.dart';
import 'package:trustguardian/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:trustguardian/core/app_export.dart';

class LoginPageScreen extends StatelessWidget {
  LoginPageScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController lockController = TextEditingController();

  TextEditingController vectorController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.whiteA70001,
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(horizontal: 36.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgCashOnWallet,
                height: 267.v,
                width: 276.h,
                margin: EdgeInsets.only(right: 9.h),
              ),
              SizedBox(height: 1.v),
              Align(
                alignment: Alignment.center,
                child: SizedBox(
                  width: 90.h,
                  child: Text(
                    "Login",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: theme.textTheme.displaySmall!.copyWith(
                      height: 1.83,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 10.v),
              Container(
                width: 282.h,
                margin: EdgeInsets.only(right: 3.h),
                child: Text(
                  "Welcome back! Please sign in to access your account.",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: CustomTextStyles.titleLargeChenla,
                ),
              ),
              SizedBox(height: 46.v),
              Container(
                height: 34.v,
                width: 221.h,
                margin: EdgeInsets.only(right: 20.h),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        width: 58.h,
                        margin: EdgeInsets.only(left: 21.h),
                        child: Text(
                          "Username",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodySmall!.copyWith(
                            height: 1.67,
                          ),
                        ),
                      ),
                    ),
                    CustomTextFormField(
                      width: 221.h,
                      controller: lockController,
                      alignment: Alignment.center,
                      suffix: Container(
                        margin: EdgeInsets.symmetric(
                          horizontal: 10.h,
                          vertical: 9.v,
                        ),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgLock,
                          height: 15.adaptSize,
                          width: 15.adaptSize,
                        ),
                      ),
                      suffixConstraints: BoxConstraints(
                        maxHeight: 34.v,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16.v),
              Container(
                height: 34.v,
                width: 221.h,
                margin: EdgeInsets.only(right: 20.h),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        width: 53.h,
                        margin: EdgeInsets.only(left: 23.h),
                        child: Text(
                          "Password",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodySmall!.copyWith(
                            height: 1.67,
                          ),
                        ),
                      ),
                    ),
                    CustomTextFormField(
                      width: 221.h,
                      controller: vectorController,
                      textInputAction: TextInputAction.done,
                      alignment: Alignment.center,
                      suffix: Container(
                        margin: EdgeInsets.symmetric(
                          horizontal: 8.h,
                          vertical: 7.v,
                        ),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgVector,
                          height: 14.adaptSize,
                          width: 14.adaptSize,
                        ),
                      ),
                      suffixConstraints: BoxConstraints(
                        maxHeight: 34.v,
                      ),
                      obscureText: true,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 49.v),
              CustomElevatedButton(
                text: "Log In",
                margin: EdgeInsets.only(
                  left: 45.h,
                  right: 20.h,
                ),
              ),
              SizedBox(height: 3.v),
              Container(
                width: 189.h,
                margin: EdgeInsets.only(right: 29.h),
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "Don’t have an account?  ",
                        style: CustomTextStyles.bodySmallff000000,
                      ),
                      TextSpan(
                        text: "Sign Up",
                        style: CustomTextStyles.bodySmallff3836c1.copyWith(
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }
}
