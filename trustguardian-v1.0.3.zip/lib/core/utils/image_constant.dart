class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Signup Page images
  static String imgClose = '$imagePath/img_close.svg';

  static String imgCheckmark = '$imagePath/img_checkmark.svg';

  static String imgArrowup = '$imagePath/img_arrowup.svg';

  // HomePage images
  static String imgSearch = '$imagePath/img_search.png';

  static String imgGroup27 = '$imagePath/img_group_27.svg';

  static String imgFire = '$imagePath/img_fire.png';

  static String imgPhishingStealData = '$imagePath/img_phishing_steal_data.png';

  static String imgReport = '$imagePath/img_report.png';

  static String imgDiscussion = '$imagePath/img_discussion.png';

  static String imgMore = '$imagePath/img_more.png';

  static String imgNews = '$imagePath/img_news.svg';

  // Profile images
  static String imgBack = '$imagePath/img_back.png';

  static String imgGroup14 = '$imagePath/img_group_14.png';

  static String imgRectangle142x143 = '$imagePath/img_rectangle_142x143.png';

  static String imgThumbsUp = '$imagePath/img_thumbs_up.svg';

  static String imgNavNews = '$imagePath/img_nav_news.svg';

  // Common images
  static String imgCashOnWallet = '$imagePath/img_cash_on_wallet.png';

  static String imgLock = '$imagePath/img_lock.svg';

  static String imgVector = '$imagePath/img_vector.svg';

  static String imgNavHome = '$imagePath/img_nav_home.svg';

  static String imgLockWhiteA70001 = '$imagePath/img_lock_white_a700_01.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
