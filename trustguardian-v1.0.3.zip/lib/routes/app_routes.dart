import 'package:flutter/material.dart';
import '../presentation/login_signup_screen/login_signup_screen.dart';
import '../presentation/signup_page_screen/signup_page_screen.dart';
import '../presentation/login_page_screen/login_page_screen.dart';
import '../presentation/profile_screen/profile_screen.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String loginSignupScreen = '/login_signup_screen';

  static const String signupPageScreen = '/signup_page_screen';

  static const String loginPageScreen = '/login_page_screen';

  static const String homepagePage = '/homepage_page';

  static const String profileScreen = '/profile_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    loginSignupScreen: (context) => LoginSignupScreen(),
    signupPageScreen: (context) => SignupPageScreen(),
    loginPageScreen: (context) => LoginPageScreen(),
    profileScreen: (context) => ProfileScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
